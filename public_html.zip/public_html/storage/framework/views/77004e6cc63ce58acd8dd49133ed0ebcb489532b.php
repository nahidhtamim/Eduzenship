<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Query Email</title>
</head>
<body>
    <div class="card">
        <div class="card-header">
            Contact Email
        </div>
        <div class="card-header">
            <p>Name : <?php echo e($details['name']); ?></p>
            <p>Email : <?php echo e($details['email']); ?></p>
            <p>Phone : <?php echo e($details['phone']); ?></p>
            <p>Address : <?php echo e($details['address']); ?></p>
            <p>IELTS Complete? (Yes/No) : <?php echo e($details['ielts']); ?></p>
            <p>Countries : <?php echo e($details['countries']); ?></p>
            <p>Message : <?php echo e($details['message']); ?></p>
        </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\github\ivyproplacements\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>